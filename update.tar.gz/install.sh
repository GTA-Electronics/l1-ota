#!/bin/sh

OTA_DIR="/tmp/.ota/update"

dd if=$OTA_DIR/images/boot.img of=/dev/block/by-name/boot
cp -rf $OTA_DIR/files/* /

# Chown user files if they exist
if [ -d $OTA_DIR/files/home/user ]; then
	chown user:user -R /home/user/
fi

depmod -a 2>/dev/null
