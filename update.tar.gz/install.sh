#!/bin/sh

OTA_DIR="/tmp/.ota/update"

blk_device=/dev/block/by-name/boot

[ -L /dev/disk/by-partlabel/boot ] && blk_device=/dev/disk/by-partlabel/boot

dd if=$OTA_DIR/images/boot.img of=$blk_device
cp -rf $OTA_DIR/files/* /

# Chown user files if they exist
if [ -d $OTA_DIR/files/home/user ]; then
	chown user:user -R /home/user/
fi

depmod -a 2>/dev/null
